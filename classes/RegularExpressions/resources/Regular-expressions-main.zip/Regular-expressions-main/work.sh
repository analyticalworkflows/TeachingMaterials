sed 's/the/a/g' the.txt
